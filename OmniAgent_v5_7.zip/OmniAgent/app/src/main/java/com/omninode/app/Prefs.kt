package com.omninode.app

import android.content.Context

/** Общие настройки приложения (SharedPreferences "omni"). */
object Prefs {
    fun sp(c: Context) = c.getSharedPreferences("omni", Context.MODE_PRIVATE)

    fun b(c: Context, k: String, def: Boolean = false): Boolean = sp(c).getBoolean(k, def)

    fun set(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }

    /** Все переключатели одним JSON — для экрана настроек. */
    fun toggles(c: Context): String {
        val o = org.json.JSONObject()
        o.put("core_on", b(c, "core_on"))
        o.put("island_on", b(c, "island_on"))
        o.put("hide_games", b(c, "hide_games", true))
        o.put("bg_on", b(c, "bg_on"))
        o.put("tts_assistant", b(c, "tts_assistant"))
        o.put("tts_user", b(c, "tts_user"))
        o.put("tts_agent", b(c, "tts_agent", true))
        o.put("confirm_pay", b(c, "confirm_pay", true))
        return o.toString()
    }
}
